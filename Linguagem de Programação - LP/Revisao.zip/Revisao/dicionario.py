    #Armazena valores por chave

aluno = {
    'nome': "Amanda",
    'idade': 17,
    'nota': 9.0
}

print (aluno['nome'])


#Alterando Valores
aluno['nota'] = 9.5


#Adicionando nova chave
aluno['turma'] = "3A"

print(aluno)