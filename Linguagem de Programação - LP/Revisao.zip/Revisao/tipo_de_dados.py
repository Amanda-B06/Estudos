idade = 18          # int

altura = 1.60       # float

nome = "Amanda"     # srt

maior = True        # bool

