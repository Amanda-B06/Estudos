frutas = ["Maçã", "Banana", "Mamão"]

#Acessando
print (frutas[0])   # Maçã


#Adicioando
frutas.append("Uva")


#Removendo
frutas.remove("Banana")


#Alterando
frutas[1] = "Abacaxi"

print(frutas)