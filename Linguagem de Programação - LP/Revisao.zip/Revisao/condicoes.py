nota = 7

if nota >= 7:
    print ("Aprovado.")

elif nota >= 5:
    print ("Recuperação.")

else:
    print ("Reprovado.")

#       == igual
#       != diferente
#       > maior
#       < menor
#       >= maior ou igual
#       <= menor ou igual
#       and (e)
#       or (ou)

idade = 18
tem_carteira = True

if idade >= 18 and tem_carteira:
    print ("Pode dirigit")