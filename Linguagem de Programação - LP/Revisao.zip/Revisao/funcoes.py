    # Função simples

def saudacao():
    print("Bem-Vindo!")


    # Chamando
saudacao()


    # Função com parametros
def soma (a, b):
    return a + b

resultado = soma (5,3)
print(resultado)