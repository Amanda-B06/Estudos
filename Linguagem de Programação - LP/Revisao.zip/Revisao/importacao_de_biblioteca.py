import math
import pandas as pd
import automacao
from datetime import datetime

    #Importando com apelido

import pandas as pd