contador = 1

while contador <= 5:
    print (contador)
    contador += 1