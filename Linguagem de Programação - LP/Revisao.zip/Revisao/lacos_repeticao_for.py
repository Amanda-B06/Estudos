for i in range(5):
    print ("Olá, ", i)


frutas = ["Maçã", "Banana", "Uva"]
for fruta in frutas :
    print (fruta)