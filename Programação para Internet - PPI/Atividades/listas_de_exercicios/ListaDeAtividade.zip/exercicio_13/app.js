//13 -


let i = 10;

while(i>=0){

    console.log(i)
    i--
    
}